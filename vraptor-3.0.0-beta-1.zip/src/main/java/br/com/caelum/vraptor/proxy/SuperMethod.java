package br.com.caelum.vraptor.proxy;

/**
 * @author Fabio Kung
 */
public interface SuperMethod {

    Object invoke(Object proxy, Object[] args);
}
