package br.com.caelum.vraptor.validator;

public interface Message {
	
	String getMessage();
	
	String getCategory();

}
