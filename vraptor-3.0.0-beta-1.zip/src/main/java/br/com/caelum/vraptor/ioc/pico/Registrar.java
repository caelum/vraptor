package br.com.caelum.vraptor.ioc.pico;

public interface Registrar {

    void registerFrom(Scanner scanner);

}
